<head> <!-- About to script -->
<?php
echo "<!-- -->\n";
/* ?> */
?>
<strong>for</strong><b>if</b>
